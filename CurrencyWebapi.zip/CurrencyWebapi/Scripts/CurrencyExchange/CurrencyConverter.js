﻿//Document loaded
$(document).ready(function () {
	//On button click
	$("#btnsubmit").on("click", function () {
		//Hiding error display tr
		$("#trError").hide();
		//Validating amount
		if ($("#txtAmount").val() === "") {
			alert("Please enter 'Amount'");
			$("#txtAmount").focus();
			return false;
		}
		else if ($.isNumeric($("#txtAmount").val()) === false) {
			alert("Please enter number or decimal values.");
			$("#txtAmount").focus();
			return false;
		}

		$("#resultforOutput").html("Request Status :- Please wait...").addClass("label label-default");
		//Preparing json data
		var datatobesent = JSON.stringify({
			amount: $("#txtAmount").val(),
			currency: $("#sCurrency option:selected").val()
		});
		//Ajax call to get exchange rate
		$.ajax({
			type: "POST",
			async: true,
			url: "/api/v0/rate",
			data: datatobesent,
			success: function (responsedata) {
				GetExchangeResponse(responsedata);
			},
			dataType: 'json',
			contentType: "application/json",
		})
		.fail(function (jqXHR, textStatus) {
			ErrorAtExchangeResponse(jqXHR, textStatus);
		})
		;
	});
	//Api v0/rate
	//On api success
	function GetExchangeResponse(responsedata) {
		$("#lblConversionRate").html(responsedata.ExchangeRate);
		$("#lblTotal").html(parseFloat(responsedata.total).toFixed(2));
		$("#lblReturnCode").html(1);
		$("#lblReturnCode").addClass("label label-success");
		$("#lblError").html("");
		$("#lblTimeStamp").html(responsedata.Tics);
		$("#resultforOutput").html("Request Status :- Complete").addClass("label label-success");
	}

	//on api error v0/rate
	function ErrorAtExchangeResponse(pJqXHR, pTextStatus) {
		$("#trError").show();
		$("#lblReturnCode").html(0);
		$("#lblReturnCode").addClass("label label-danger");
		$("#lblError").html('Error Code = ' + pTextStatus + '\n Message = ' + pJqXHR.statusText);
		$("#resultforOutput").html("Request Status :- Complete").addClass("label label-danger");
	}
});