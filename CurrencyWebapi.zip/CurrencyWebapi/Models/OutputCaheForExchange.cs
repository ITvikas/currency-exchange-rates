﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Reflection;
namespace CurrencyWebapi.Models
{
	/// <summary>
	/// 
	/// </summary>
	public class OutputCaheForExchange : System.Web.Mvc.OutputCacheAttribute
	{
		public OutputCaheForExchange(Type type)
		{
			PropertyInfo[] properties = type.GetProperties();
			VaryByParam = "Currency;Amount";
			Duration = 7200;
		}
	}
}