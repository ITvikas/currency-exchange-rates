﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurrencyWebapi.Models
{
	/// <summary>
	/// 
	/// </summary>
	public class Exchangerate
	{
		public string CurrencyName { get; set; }
		public Double ExchangeRate { get; set; }
	}
}