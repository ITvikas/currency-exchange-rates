﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurrencyWebapi.Models
{
	public class Currencies
	{
		//default currencies
		public enum enumCurrencies
		{
			AUD = 1,
			CAD = 2,
			EUR = 3,
			GBP = 4,
			SGD = 5,
			USD = 6

		}
	}
}