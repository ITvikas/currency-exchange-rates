﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CurrencyWebapi.Models;
using System.IO;

namespace CurrencyWebapi.Controllers
{
	public class CurrencyExchangeController : ApiController
	{
		// Async api rest client call from azure cloud service
		[HttpGet]
		public async void GetAndUpdateExchangeRates()
		{
			try
			{
				await Task.Run(() => UpdateDBExchangeRates());
			}
			catch (Exception)
			{
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void UpdateDBExchangeRates()
		{
			List<Exchangerate> ObjCurrency = null;
			// default currencies
			IEnumerable<Currencies.enumCurrencies> eCur = null;
			CurrencyExchangeRate excrate = null; CurrencyExchangeRate DBexchangerow = null;

			try
			{
				TimeSpan ts;
				string currencrName = string.Empty;
				// base currency
				const string toCurrrency = "INR";
				bool IsDBChanged = false;
				//get defaults currencies from Enums
				eCur = Enum.GetValues(typeof(Currencies.enumCurrencies)).Cast<Currencies.enumCurrencies>();
				ObjCurrency = new List<Exchangerate>();
				foreach (var Curren in eCur)
				{
					ObjCurrency.Add(new Exchangerate()
					{
						CurrencyName = Curren.ToString(),
						//getting exchange rate for currency
						ExchangeRate = GetExchangeRate(1M, Curren.ToString(), toCurrrency)
					});
				}

				excrate = new CurrencyExchangeRate();
				using (ITDBEntities db = new ITDBEntities())
				{
					// looping through each currency and update mode and save to DB
					foreach (Currencies.enumCurrencies Curren in eCur)
					{
						currencrName = Convert.ToString(Curren);
						excrate.Currency = currencrName;
						excrate.ExchangeRate = ObjCurrency.FirstOrDefault(x => x.CurrencyName == currencrName).ExchangeRate;
						excrate.UpdatedOn = DateTime.Now;// default value
						excrate.Tics = "0";// default value

						//get DB row for the current currency
						DBexchangerow = db.CurrencyExchangeRates.Find(currencrName);
						if (DBexchangerow == null)
						{
							db.CurrencyExchangeRates.Add(excrate);
							IsDBChanged = true;
						}
						else
						{
							if (DBexchangerow.ExchangeRate != excrate.ExchangeRate)
							{
								DBexchangerow.Currency = currencrName;
								DBexchangerow.ExchangeRate = excrate.ExchangeRate;
								ts = Convert.ToDateTime(excrate.UpdatedOn).Subtract(Convert.ToDateTime(DBexchangerow.UpdatedOn));
								DBexchangerow.Tics = ts.Ticks.ToString();
								if (IsDBChanged == false) IsDBChanged = true;
							}
						}
					}
					// update only if model has changed
					if (IsDBChanged) db.SaveChanges();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				//Disposing of objects
				if (ObjCurrency != null)
				{
					ObjCurrency.Clear(); ObjCurrency = null;
				}
				if (eCur != null)
				{
					eCur = null;
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="amount"></param>
		/// <param name="fromCurrency"></param>
		/// <param name="toCurrency"></param>
		/// <returns></returns>
		public double GetExchangeRate(decimal amount, string fromCurrency, string toCurrency)
		{
			//System.IO.StreamReader streamReader = null;
			try
			{
				string result = null;
				string ApiURL = String.Format("https://www.google.com/finance/converter?a={0}&from={1}&to={2}&meta={3}", amount, fromCurrency, toCurrency, Guid.NewGuid().ToString());

				//Make your Web Request and grab the results
				var request = WebRequest.Create(ApiURL);

				//Get the Response
				using (StreamReader streamReader = new StreamReader(request.GetResponse().GetResponseStream(), System.Text.Encoding.ASCII))
				{
					//Grab your converted value
					result = Regex.Matches(streamReader.ReadToEnd(), "<span class=\"?bld\"?>([^<]+)</span>")[0].Groups[1].Value;
				}
				return Convert.ToDouble(Convert.ToString(result).Replace(toCurrency.ToUpper(), "").Trim());
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}