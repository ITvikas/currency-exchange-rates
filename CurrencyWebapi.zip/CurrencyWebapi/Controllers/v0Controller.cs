﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using CurrencyWebapi.Models;
namespace CurrencyWebapi.Controllers
{
	public class v0Controller : ApiController
	{
		// POST api/v0
		[HttpPost]
		//for caching
		[OutputCaheForExchange(typeof(CurrencyExchangeModel))]
		//api call to get exchange update exchange model from DB
		public CurrencyExchangeModel rate(CurrencyExchangeModel currencyExchangeModel)
		{
			try
			{
				using (var db = new ITDBEntities())
				{
					CurrencyExchangeRate exchangerow = db.CurrencyExchangeRates.Find(currencyExchangeModel.Currency);
					currencyExchangeModel.total = Math.Round(currencyExchangeModel.Amount * exchangerow.ExchangeRate, 2, MidpointRounding.AwayFromZero);
					currencyExchangeModel.Tics = exchangerow.Tics;
					currencyExchangeModel.ExchangeRate = exchangerow.ExchangeRate;
				}
				// returing exchange model back
				return currencyExchangeModel;
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}
	}
}